---
name: Feature request
about: For requesting new features
title: ''
labels: feature request
assignees: ayrton04

---

## Feature request

#### Feature description
<!-- Description in a few sentences what the feature consists of and what problem it will solve -->

#### Implementation considerations
<!-- Relevant information on how the feature could be implemented and pros and cons of the different solutions -->
